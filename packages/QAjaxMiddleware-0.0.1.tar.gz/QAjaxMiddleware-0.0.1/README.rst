=====
QAjaxMiddleware
=====

Quick start
-----------

1. Add "qajaxmiddleware" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...,
        "qajaxmiddleware",
    ]


