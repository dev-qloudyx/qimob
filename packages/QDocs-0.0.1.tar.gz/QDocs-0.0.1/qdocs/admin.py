
from django.contrib import admin

from qdocs.models import File
# Register your models here.

admin.site.register(File)
