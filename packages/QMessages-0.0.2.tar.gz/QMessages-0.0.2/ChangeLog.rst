
0.00.1 (2023-11-27)
*******************
- Initial release

0.00.2 (2024-01-05)
*******************

- Refactor the 'get' method of class MessageListView to retrieve new fields
  from the database.